<% "---" %>
tags: 📥/📀
fileclass: movie
cover: {{VALUE:Poster}}
created: <% tp.file.creation_date("YYYY-MM-DD") %>
modified: <% tp.file.last_modified_date("YYYY-MM-DD") %>
<% "---" %>

> {{VALUE:Plot}}

![|200]({{VALUE:Poster}})


---

> [!meta]+ Metadaten
> - Year:: {{VALUE:Year}}
> - Genre:: {{VALUE:Genre}}
> - Language:: {{VALUE:Language}}
> - Status:: to-watch
> - Watched:: 